import uuid

def book_service_slot(date: str, center: str) -> dict:
    """
    Books service slot.
    """
    return {
        "booking_id": str(uuid.uuid4()),
        "date": date,
        "center": center,
        "status": "CONFIRMED"
    }