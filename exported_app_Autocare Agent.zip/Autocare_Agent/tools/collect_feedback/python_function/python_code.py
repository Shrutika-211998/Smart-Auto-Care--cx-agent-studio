import uuid
import random

def collect_feedback(message: str) -> dict:
    ticket_id = "FB-" + str(random.randint(10000, 99999))

    return {
        "ticket_id": ticket_id,
        "status": "SUBMITTED"
    }