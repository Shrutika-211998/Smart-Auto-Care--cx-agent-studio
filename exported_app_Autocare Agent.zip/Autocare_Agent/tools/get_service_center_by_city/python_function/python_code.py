def get_service_center_by_city(city: str) -> dict:
    """
    Returns service center address for a given city.
    """
    centers = {
        "new york": {
            "name": "Brooklyn Service Hub",
            "address": "1 2nd Ave, Brooklyn, NY 34567",
            "phone": "+1-212-555-1234"
        },
        "chicago": {
            "name": "Chicago AutoCare Center",
            "address": "1345 W Lake St, Chicago, IL 60607",
            "phone": "+1-312-555-5678"
        }
    }

    city_lower = city.lower()

    if city_lower in centers:
        return {
            "status": "SUCCESS",
            "center_details": centers[city_lower]
        }
    else:
        return {
            "status": "NOT_FOUND"
        }