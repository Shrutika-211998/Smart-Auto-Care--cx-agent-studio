def check_warranty(vehicle_number: str) -> dict:
    """
    Returns warranty information.
    """
    return {
        "warranty_valid": True,
        "expiry_date": "2027-05-01"
    }