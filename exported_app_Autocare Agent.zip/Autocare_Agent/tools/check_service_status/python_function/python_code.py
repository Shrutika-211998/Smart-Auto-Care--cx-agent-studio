def check_service_status(vehicle_number: str) -> dict:
    """
    Returns mock service status.
    """
    return {
        "status": "IN_PROGRESS",
        "stage": "Engine inspection completed",
        "estimated_completion": "2 days"
    }